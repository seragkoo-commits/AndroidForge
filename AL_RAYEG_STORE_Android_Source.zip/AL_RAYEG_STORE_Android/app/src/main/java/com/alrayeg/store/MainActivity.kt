package com.alrayeg.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val Ink = Color(0xFF071719)
private val Panel = Color(0xFF102D32)
private val Cyan = Color(0xFF4DE3D0)
private val Muted = Color(0xFF7A8B8D)
private val Good = Color(0xFF16A085)
private val Warn = Color(0xFFE3A34D)

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val currency: String = "SDG",
    val openingBalance: Double = 0.0
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val type: String,
    val description: String,
    val amount: Double,
    val cost: Double = 0.0,
    val fee: Double = 0.0,
    val currency: String = "SDG",
    val accountName: String = "Cash",
    val quantity: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val syncStatus: String = "PENDING"
)

@Entity(tableName = "stock_lots")
data class StockLotEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val product: String,
    val source: String,
    val purchasedQty: Double,
    val remainingQty: Double,
    val totalCost: Double,
    val remainingCost: Double,
    val currency: String = "SDG",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface StoreDao {
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun transactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM accounts ORDER BY name")
    fun accounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM stock_lots ORDER BY createdAt DESC")
    fun stockLots(): Flow<List<StockLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addTransaction(t: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAccount(a: AccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addStockLot(lot: StockLotEntity)

    @Query("SELECT COUNT(*) FROM accounts")
    suspend fun accountCount(): Int

    @Query("SELECT COUNT(*) FROM stock_lots")
    suspend fun stockCount(): Int

    @Query("SELECT SUM(remainingQty) FROM stock_lots WHERE product = :product")
    suspend fun remainingQuantity(product: String): Double?

    @Query("SELECT SUM(remainingCost) FROM stock_lots WHERE product = :product")
    suspend fun remainingCost(product: String): Double?

    @Query("SELECT * FROM stock_lots WHERE product = :product AND remainingQty > 0 ORDER BY createdAt ASC")
    suspend fun lotsForProduct(product: String): List<StockLotEntity>

    @Update
    suspend fun updateLot(lot: StockLotEntity)

    @Transaction
    suspend fun seedIfEmpty() {
        if (accountCount() == 0) {
            addAccount(AccountEntity(name = "الكاش"))
            addAccount(AccountEntity(name = "المحفظة الإلكترونية"))
            addAccount(AccountEntity(name = "منصة الشحن"))
            addAccount(AccountEntity(name = "حساب USDT", currency = "USDT"))
            addAccount(AccountEntity(name = "البنك"))
        }
    }
}

@Database(
    entities = [AccountEntity::class, TransactionEntity::class, StockLotEntity::class],
    version = 1,
    exportSchema = false
)
abstract class StoreDatabase : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var INSTANCE: StoreDatabase? = null
        fun get(context: android.content.Context): StoreDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, StoreDatabase::class.java, "alrayeg_store.db"
                ).build().also { INSTANCE = it }
            }
    }
}

class StoreViewModel(private val dao: StoreDao) : ViewModel() {
    val transactions = dao.transactions()
    val accounts = dao.accounts()
    val stock = dao.stockLots()

    var message by mutableStateOf("")
        private set

    init { viewModelScope.launch { dao.seedIfEmpty() } }

    fun addTransaction(type: String, description: String, amountText: String, costText: String,
                       feeText: String, account: String, quantityText: String, currency: String) {
        val amount = amountText.toDoubleOrNull()
        val cost = costText.toDoubleOrNull() ?: 0.0
        val fee = feeText.toDoubleOrNull() ?: 0.0
        val qty = quantityText.toDoubleOrNull() ?: 0.0
        if (amount == null || amount <= 0) {
            message = "أدخل مبلغاً صحيحاً أكبر من صفر"
            return
        }
        if (cost < 0 || fee < 0 || qty < 0) {
            message = "التكلفة والرسوم والكمية لا يمكن أن تكون سالبة"
            return
        }
        viewModelScope.launch {
            dao.addTransaction(TransactionEntity(
                type = type, description = description.ifBlank { type },
                amount = amount, cost = cost, fee = fee,
                accountName = account, quantity = qty, currency = currency
            ))
            message = "تم حفظ العملية محلياً. المزامنة السحابية غير مفعّلة بعد."
        }
    }

    fun addPurchase(qtyText: String, costText: String, source: String) {
        val qty = qtyText.toDoubleOrNull()
        val cost = costText.toDoubleOrNull()
        if (qty == null || qty <= 0 || cost == null || cost < 0) {
            message = "راجع كمية الشدات والتكلفة"
            return
        }
        viewModelScope.launch {
            dao.addStockLot(StockLotEntity(
                product = "PUBG UC", source = source,
                purchasedQty = qty, remainingQty = qty,
                totalCost = cost, remainingCost = cost
            ))
            dao.addTransaction(TransactionEntity(
                type = "شراء مخزون",
                description = "شراء $qty UC — $source",
                amount = cost, cost = cost, quantity = qty,
                accountName = "المخزون", syncStatus = "PENDING"
            ))
            message = "تم تسجيل دفعة المخزون محلياً"
        }
    }
}

class StoreViewModelFactory(private val dao: StoreDao) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = StoreViewModel(dao) as T
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = StoreDatabase.get(this).dao()
        setContent {
            val vm: StoreViewModel = viewModel(factory = StoreViewModelFactory(dao))
            StoreApp(vm)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreApp(vm: StoreViewModel) {
    var page by remember { mutableStateOf("home") }
    var txs by remember { mutableStateOf(emptyList<TransactionEntity>()) }
    var lots by remember { mutableStateOf(emptyList<StockLotEntity>()) }
    var accounts by remember { mutableStateOf(emptyList<AccountEntity>()) }
    LaunchedEffect(Unit) {
        launch { vm.transactions.collect { txs = it } }
        launch { vm.stock.collect { lots = it } }
        launch { vm.accounts.collect { accounts = it } }
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Good, background = Ink, surface = Panel,
            onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AL-RAYEG STORE", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                            Text("نظام المحاسبة والمخزون", fontSize = 12.sp, color = Muted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Panel)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" },
                        icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = page == "add", onClick = { page = "add" },
                        icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("عملية جديدة") })
                    NavigationBarItem(selected = page == "stock", onClick = { page = "stock" },
                        icon = { Icon(Icons.Default.Inventory2, null) }, label = { Text("المخزون") })
                    NavigationBarItem(selected = page == "history", onClick = { page = "history" },
                        icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("الحركات") })
                }
            }
        ) { padding ->
            when (page) {
                "home" -> HomeScreen(txs, lots, accounts, Modifier.padding(padding))
                "add" -> AddScreen(vm, accounts.map { it.name }, Modifier.padding(padding))
                "stock" -> StockScreen(lots, Modifier.padding(padding))
                else -> HistoryScreen(txs, Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(txs: List<TransactionEntity>, lots: List<StockLotEntity>,
               accounts: List<AccountEntity>, modifier: Modifier = Modifier) {
    val sales = txs.filter { it.type == "بيع / شحن" }.sumOf { it.amount }
    val profit = txs.filter { it.type == "بيع / شحن" }.sumOf { it.amount - it.cost - it.fee }
    val stockQty = lots.sumOf { it.remainingQty }
    val stockValue = lots.sumOf { it.remainingCost }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("ملخص المتجر", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("بيانات محفوظة على هذا الجهاز", color = Muted, fontSize = 13.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("المبيعات المسجلة", fmt(sales), "ج.س", Modifier.weight(1f))
                MetricCard("ربح العمليات", fmt(profit), "ج.س", Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("مخزون UC", fmt(stockQty), "UC", Modifier.weight(1f))
                MetricCard("قيمة المخزون", fmt(stockValue), "ج.س", Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("حساباتك", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    accounts.forEach { Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalanceWallet, null, tint = Cyan, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(it.name, modifier = Modifier.weight(1f))
                        Text(it.currency, color = Muted, fontSize = 12.sp)
                    } }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudSync, null, tint = Warn)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("المزامنة السحابية", fontWeight = FontWeight.Bold)
                        Text("البنية جاهزة للتطوير؛ يلزم إعداد خادم ومصادقة قبل تفعيلها.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Cyan)
            Text(unit, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun AddScreen(vm: StoreViewModel, accountNames: List<String>, modifier: Modifier = Modifier) {
    var type by remember { mutableStateOf("بيع / شحن") }
    var desc by remember { mutableStateOf("شحن PUBG UC") }
    var amount by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var fee by remember { mutableStateOf("0") }
    var qty by remember { mutableStateOf("") }
    var account by remember { mutableStateOf(accountNames.firstOrNull() ?: "الكاش") }
    var currency by remember { mutableStateOf("SDG") }
    var source by remember { mutableStateOf("شراء مسبق") }
    var showAccount by remember { mutableStateOf(false) }
    var showSource by remember { mutableStateOf(false) }

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("تسجيل عملية جديدة", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            Text("نوع العملية", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("بيع / شحن", "شراء", "مصروف", "تحويل", "سحب شخصي").forEach { option ->
                    FilterChip(selected = type == option, onClick = { type = option },
                        label = { Text(option, fontSize = 11.sp) })
                }
            }
        }
        item { OutlinedTextField(desc, { desc = it }, label = { Text("الوصف / العميل / رقم الطلب") },
            modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item { OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ") },
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
        if (type == "بيع / شحن" || type == "شراء") {
            item { OutlinedTextField(cost, { cost = it }, label = { Text("تكلفة البضاعة أو الشراء") },
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
            item { OutlinedTextField(qty, { qty = it }, label = { Text("الكمية (مثلاً UC)") },
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
        }
        item { OutlinedTextField(fee, { fee = it }, label = { Text("الرسوم والعمولات") },
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true) }
        item {
            ExposedDropdownMenuBox(expanded = showAccount, onExpandedChange = { showAccount = it }) {
                OutlinedTextField(account, {}, readOnly = true, label = { Text("الحساب") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(showAccount) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = showAccount, onDismissRequest = { showAccount = false }) {
                    accountNames.forEach { name ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { account = name; showAccount = false })
                    }
                }
            }
        }
        item {
            ExposedDropdownMenuBox(expanded = showSource, onExpandedChange = { showSource = it }) {
                OutlinedTextField(source, {}, readOnly = true, label = { Text("مصدر الشدات") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(showSource) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = showSource, onDismissRequest = { showSource = false }) {
                    listOf("شراء مسبق", "شراء مباشر لطلب").forEach { s ->
                        DropdownMenuItem(text = { Text(s) }, onClick = { source = s; showSource = false })
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SDG", "USD", "USDT", "EGP").forEach { c ->
                    FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) })
                }
            }
        }
        item {
            Button(
                onClick = {
                    if (type == "شراء") vm.addPurchase(qty, cost.ifBlank { amount }, source)
                    else vm.addTransaction(type, desc, amount, cost, fee, account, qty, currency)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink)
            ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("حفظ العملية") }
        }
        if (vm.message.isNotBlank()) item {
            Text(vm.message, color = Cyan, fontSize = 13.sp)
        }
        item {
            Text("ملاحظة: هذه نسخة أولية؛ ترحيل القيود المزدوجة والمزامنة الفعلية وإقفال اليوم ستُستكمل في المرحلة التالية.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun StockScreen(lots: List<StockLotEntity>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("المخزون", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item {
            val qty = lots.sumOf { it.remainingQty }
            val value = lots.sumOf { it.remainingCost }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("الرصيد المتبقي", fmt(qty), "UC", Modifier.weight(1f))
                MetricCard("قيمة المخزون", fmt(value), "ج.س", Modifier.weight(1f))
            }
        }
        if (lots.isEmpty()) item { EmptyCard("ما في دفعات مخزون مسجلة لسه") }
        items(lots.size) { i ->
            val lot = lots[i]
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(lot.product, fontWeight = FontWeight.Bold)
                    Text("المصدر: ${lot.source}", color = Muted, fontSize = 12.sp)
                    Text("الكمية الأصلية: ${fmt(lot.purchasedQty)} UC")
                    Text("المتبقي: ${fmt(lot.remainingQty)} UC")
                    Text("التكلفة المتبقية: ${fmt(lot.remainingCost)} ج.س", color = Cyan)
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(txs: List<TransactionEntity>, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("سجل الحركات", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (txs.isEmpty()) item { EmptyCard("ما في حركات مسجلة لسه") }
        items(txs.size) { i ->
            val tx = txs[i]
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        when (tx.type) {
                            "بيع / شحن" -> Icons.Default.TrendingUp
                            "شراء" -> Icons.Default.ShoppingCart
                            "مصروف" -> Icons.Default.Receipt
                            else -> Icons.Default.SwapHoriz
                        }, null, tint = Cyan
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tx.description, fontWeight = FontWeight.Bold)
                        Text("${tx.type} • ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date(tx.createdAt))}",
                            color = Muted, fontSize = 11.sp)
                        Text("${tx.accountName} • ${tx.syncStatus}", color = Muted, fontSize = 10.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(fmt(tx.amount), fontWeight = FontWeight.Bold, color = Cyan)
                        Text(tx.currency, color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Text(text, Modifier.padding(18.dp), color = Muted)
    }
}

private fun fmt(n: Double): String =
    NumberFormat.getNumberInstance(Locale.US).format(n)
